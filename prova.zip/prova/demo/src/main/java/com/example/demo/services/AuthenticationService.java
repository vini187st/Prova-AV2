package com.example.demo.services;

import com.example.demo.dtos.RegisterRequestDTO;
import com.example.demo.entities.User;
import com.example.demo.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthenticationService implements UserDetailsService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return userRepository.findByLogin(username);
    }

    public UserDetails register(RegisterRequestDTO data) {
        if (this.userRepository.findByLogin(data.login()) != null) {
            throw new RuntimeException("Este login já está em uso.");
        }

        String encryptedPassword = this.passwordEncoder.encode(data.password());
        User newUser = new User(data.login(), encryptedPassword);
        this.userRepository.save(newUser);

        return newUser;
    }
}