package com.example.demo.dtos;

public record LoginRequestDTO(String login, String password) {
}