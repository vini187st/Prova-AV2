package com.example.demo.dtos;

public record RegisterRequestDTO(String login, String password) {
}